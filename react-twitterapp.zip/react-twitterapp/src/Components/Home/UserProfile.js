import React, { useEffect, useState } from "react";
import axios from "axios";
import { Outlet, useNavigate } from "react-router-dom";
import '../../App.css'; // Ensure you import your CSS file

const Profile = () => {
    const [user, setUser] = useState({});
    const [error, setError] = useState("");
    const navigate = useNavigate();

    const handlePosts = () => navigate("Posts");
    const handleFollowers = () => navigate("Followers");
    const handleFollowing = () => navigate("Following");
    const handleEditProfile = () => navigate("EditProfile");

    useEffect(() => {
        const userId = sessionStorage.getItem("userId");
        if (userId) {
            axios
                .get(`http://localhost:5199/api/User/GetByUserId/${userId}`)
                .then((res) => {
                    if (res.status === 200) setUser(res.data);
                    else setError("Error fetching profile");
                })
                .catch((err) => {
                    setError("Error fetching profile");
                });
        }
    }, []);

    return (
        <div className="profile-container">
            <h2 className="profile-greeting">Hello, {user.userName}</h2>
            <button
                onClick={handleEditProfile}
                className="btn btn-primary profile-edit-btn"
            >
                Edit Profile
            </button>
            <div className="profile-info">
                <p><strong>User ID:</strong> {user.userId}</p>
                <p><strong>Email:</strong> {user.email}</p>
                <p><strong>Mobile Number:</strong> {user.mobileNumber}</p>
            </div>
            <div className="profile-actions">
                <button onClick={handlePosts} className="btn btn-secondary">Posts</button>
                <button onClick={handleFollowers} className="btn btn-secondary">Followers</button>
                <button onClick={handleFollowing} className="btn btn-secondary">Following</button>
            </div>
            {error && <p className="text-danger">{error}</p>}
            <Outlet/>
        </div>
    );
};

export default Profile;
