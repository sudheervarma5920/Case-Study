import React, { useState } from "react";
import { Link, Outlet, useNavigate } from "react-router-dom";
import axios from "axios";
import '../../App.css';

const Home = () => {
    const [searchQuery, setSearchQuery] = useState("");
    const [userDetails, setUserDetails] = useState(null);
    const [error, setError] = useState("");
    const navigate = useNavigate();

    const handleLogout = () => {
        sessionStorage.removeItem("token");
        navigate("/Login");
    };

    const handleSearch = () => {
        axios.get(`http://localhost:5199/api/User/GetUserById/${searchQuery}`)
            .then(res => {
                if (res.status === 200) {
                    setUserDetails(res.data);
                    setError("");
                } else {
                    setUserDetails(null);
                    setError("User not found.");
                }
            })
            .catch(err => {
                console.error(err);
                setUserDetails(null);
                setError("Error fetching user details.");
            });
    };

    return (
        <div className="page-container">
            <div className="dashboard-container">
                <nav className="nav-container">
                    <div className="nav-content">
                        <div className="title-container">
                            <h1 className="title">Twitter</h1>
                        </div>
                        <div className="search-container">
                            <input
                                type="text"
                                className="form-control search-input"
                                placeholder="Search..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                            />
                            <button className="btn btn-primary search-button" onClick={handleSearch}>Search</button>
                        </div>
                        <div className="nav-links">
                            <Link className="btn btn-outline-primary" to="">Home</Link>
                            <Link className="btn btn-outline-primary" to="Profile">Profile</Link>
                            <Link className="btn btn-outline-primary" to="AddTweet">Post</Link>
                            <button onClick={handleLogout} className="btn btn-secondary">Logout</button>
                        </div>
                    </div>
                </nav>
                <main className="content">
                    {error && <p className="error-message text-danger">{error}</p>}
                    {userDetails && (
                        <div className="user-details">
                            <h3>User Profile</h3>
                            <p><strong>User ID:</strong> {userDetails.userId}</p>
                            <p><strong>Name:</strong> {userDetails.userName}</p>
                        </div>
                    )}
                    <Outlet />
                </main>
            </div>
        </div>
    );
};

export default Home;
