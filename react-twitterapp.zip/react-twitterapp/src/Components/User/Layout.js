import React from "react";
import { Link, useNavigate } from "react-router-dom";
import '../../App.css';

export default function Layout() {
    const navigate = useNavigate();

    const handleRegister = () => navigate("/Register");
    const handleLogin = () => navigate("/Login");

    return (
        <div className="page-container">
            <header className="header">
                <h1 className="title">Twitter</h1>
                <div className="button-group">
                    <button onClick={handleRegister} className="btn btn-primary">Sign Up</button>
                    <button onClick={handleLogin} className="btn btn-secondary">Sign In</button>
                </div>
            </header>
            <div className="content-wrap">
                <div className="container text-center">
                    <p className="info-text">
                        Welcome to Twitter! Here you can stay updated with your favorite topics, connect with friends, and share your thoughts with the world. Join us today and become part of a global community.
                    </p>
                </div>
            </div>
        
        </div>
    );
}
